public class Estudante {

    String nome;
    int idade;

    InfoContatos contact;

    void estudar(){
        System.out.println("O aluno "+ nome + "esta estudando.");
    }

     void mostraInfo(){
         System.out.println("O nome do aluno eh" + nome + " e sua idade eh "+ idade);
     }




}
