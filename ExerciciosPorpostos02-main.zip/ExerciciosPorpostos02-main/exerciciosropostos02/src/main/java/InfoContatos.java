public class InfoContatos {

    String email;
    int numTelefone;
    String enderecoCasa;




}
