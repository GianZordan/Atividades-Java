public class HardwareBasico {

    public String nome;
    public float capacidade;


}
