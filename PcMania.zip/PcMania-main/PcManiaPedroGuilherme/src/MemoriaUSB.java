public class MemoriaUSB {

   public String nome;
    public int capacidade;

}
