public class Empresario {

    public long cnpj;
    public String nome;
}
