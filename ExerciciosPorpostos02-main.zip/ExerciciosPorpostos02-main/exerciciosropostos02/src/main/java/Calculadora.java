import java.util.Scanner;

import static java.lang.Math.pow;

public class Calculadora {

      int num1;
      int num2;


        void soma(){
        System.out.println(num1 + num2);
    }
      void subtracao(){
        System.out.println(num1 - num2);
    }
      void multiplicacao(){
        System.out.println(num1 * num2);
    }
        void divisao() {
        System.out.println(num1/num2);
    }
        void exponencial(){
        System.out.println(pow(num1,num2));
    }



}
