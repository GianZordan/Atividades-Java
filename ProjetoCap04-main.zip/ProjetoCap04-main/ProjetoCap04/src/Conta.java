public class Conta {

    String dono;
    int numero;
    float saldo;








}
