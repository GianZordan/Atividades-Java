public class Motor {

    String cilindradas;
    float velocidadeMaxima;


}
