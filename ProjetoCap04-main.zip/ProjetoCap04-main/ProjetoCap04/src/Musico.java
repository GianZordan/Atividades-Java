public class Musico {

    public String nome;
    public String funcao;

}
