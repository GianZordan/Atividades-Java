public class Arvore {

    // Atributos da arvore
    String especie;
    float altura;
    float diametro;
     float preco;

}
