import java.util.Scanner;

public class Classeprincipal {
    public static void main(String[] args) {

        /*
       Exercicio 1
       Calculadora c1 = new Calculadora();
       c1.num1 = 20;
       c1.num2 = 30;
       c1.soma();
       c1.subtracao();
       c1.divisao();
       c1.multiplicacao();
       c1.exponencial();

        */
        /*
       Exercicio 2

       Carro carro1 = new Carro();
       carro1.cor = "azul";
       carro1.marca = "toyota";
       carro1.modelo = "sedan";
       carro1.velocidadeMax = 120;
       carro1.velocidadeAtual = 90;
       carro1.mot.tipo = "2.0";
       carro1.mot.potencia = 200;
       carro1.acelerar();
       carro1.ligar();
       carro1.mot.mostraInfo();
       carro1.mostraInfo();

       Carro carro2 = new Carro();
       carro2.cor = "vermelha";
       carro2.marca = "Ford";
       carro2.modelo = "sedan";
       carro2.velocidadeMax = 100;
       carro2.velocidadeAtual = 70;
       carro2.mot.tipo = "1.4";
       carro2.mot.potencia = 100;
       carro2.acelerar();
       carro2.ligar();
       carro2.mot.mostraInfo();
       carro2.mostraInfo();
       */


        /*
        Exercicio 3
        Estudante estud1 = new Estudante();
        estud1.nome = "Pedro";
        estud1.idade = 19;


       InfoContatos cont1  = new InfoContatos();
       cont1.email  = "pedropgfo@mgial.com";
       cont1.enderecoCasa = "Oswaldo Campos do Amaral 860";
       cont1.numTelefone = 988944988;


       // dizendo que o contato 1 se refere ao estudante 1
       estud1.contact = cont1;

       estud1.estudar();
       estud1.mostraInfo();
        System.out.println(estud1.contact.email);
        System.out.println(estud1.contact.enderecoCasa);
        System.out.println(estud1.contact.numTelefone);

        Estudante estud2 = new Estudante();
        estud2.nome = "Lucas";
        estud2.idade = 16;

        InfoContatos cont2  = new InfoContatos();
        cont2.email  = "Lucas Saldanha Michelli";
        cont2.enderecoCasa = "Juca castelo 530";
        cont2.numTelefone = 999786654;


        // dizendo que o contato 1 se refere ao estudante 1
        estud2.contact = cont2;

        estud2.estudar();
        estud2.mostraInfo();
        System.out.println(estud2.contact.email);
        System.out.println(estud2.contact.enderecoCasa);
        System.out.println(estud2.contact.numTelefone);
        */
    }

}
