public class Motor {

    int potencia;
    String tipo;

    void mostraInfo(){
        System.out.println("A potencia do motor é "+potencia + " e seu tipo é "+tipo);
    }

}
