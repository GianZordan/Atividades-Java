public class Pessoa {

    // Caracteristicas ou Atributos
    String nome;
    int idade;
    String cpf;


    // Acoes ou Metodos
    void comer(){
        System.out.println("O(a) "+ nome + "de idade " + idade + " esta comendo");
    }

    void tomarAgua(){
        System.out.println("O(a) "+ nome + " esta tomando agua");
    }

    void dormir(){
        System.out.println("O(a) "+ nome + " esta dormindo");
    }




}
