public class SistemaOperacional {

    public String nome;
    public int tipo;
}
