public class Musica {

   public String nome;
    public String tempo;
}
