public class Piloto {

    String nome;
    boolean vilao;

    void soltaSuperPoder(){
        System.out.println("O "+ nome+" soltou um super poder");
    }



}
